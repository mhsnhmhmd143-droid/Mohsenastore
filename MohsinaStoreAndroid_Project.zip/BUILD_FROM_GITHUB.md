## أسهل طريقة لإخراج APK بدون Android Studio

1. ارفعي مجلد المشروع إلى مستودع GitHub جديد.
2. بعد رفع الملفات، افتحي تبويب Actions.
3. اختاري "Build Mohsina Store APK".
4. اضغطي Run workflow.
5. بعد نجاح البناء، افتحي نتيجة التشغيل ثم Artifacts.
6. حمّلي Mohsina-Store-debug وافكي الضغط لتحصلي على app-debug.apk.

إذا كنتِ ستستخدمين Android Studio، افتحي مجلد MohsinaStoreAndroid مباشرة ثم Build > Build APK(s).
