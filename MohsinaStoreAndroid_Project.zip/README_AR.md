# Mohsina Store — Android

هذا مشروع Android كامل لمتجر Mohsina Store، ويعرض ملف المتجر الموجود داخل:
app/src/main/assets/index.html

المميزات:
- WebView لتشغيل المتجر كتطبيق Android.
- JavaScript مفعّل لأن المتجر يعتمد عليه.
- الإنترنت مفعّل لتحميل صور المنتجات من الويب.
- زر واتساب يفتح رقم المتجر: 0926429113.
- السلة وحساب الإجمالي تعمل داخل الصفحة.
- اسم التطبيق: Mohsina Store.

للبناء:
1. افتحي المشروع في Android Studio.
2. انتظري Gradle Sync.
3. Build > Build APK(s).

ملاحظة:
هذا مشروع المصدر (Source Project)، وليس ملف APK جاهزاً. يمكن بناؤه إلى APK من Android Studio أو بيئة بناء Android مناسبة.
